   Simple serialisation for my HW.
   This package create new file and save 
serialisation data. 
   You create second file "tmp.txt", and 
contained your data for deserialization.